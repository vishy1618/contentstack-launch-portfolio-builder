export type Entry = {
  name: string;
  title: string;
  short_bio: string;
  linkedin: string;
  github: string;
  image: string;
  tags: string[];
  x: string;
}