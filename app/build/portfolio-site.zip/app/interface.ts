export type Entry = {
  name: string;
  designation: string;
  description: string;
  linkedin: string;
  github: string;
  dp: string;
  x: string;
}